<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class commType extends Controller
{
    //
}
