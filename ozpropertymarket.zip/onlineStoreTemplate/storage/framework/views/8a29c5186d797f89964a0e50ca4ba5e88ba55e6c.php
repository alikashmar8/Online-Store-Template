<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Oz Property Market</title>
    <link rel="icon" href="<?php echo e(asset('logo/fav.jpg')); ?>" type="image/gif" sizes="16x16">
    <!-- Fonts -->
    <!link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Hind&family=Pacifico&family=Sansita+Swashed&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Old+Standard+TT&family=Roboto&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Lora&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Alfa+Slab+One&display=swap" rel="stylesheet">

    
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css"/>
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>

    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css"
          integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A=="
          crossorigin=""/>

    <!-- Make sure you put this AFTER Leaflet's CSS -->
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"
            integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA=="
            crossorigin=""></script>

    <!-- Styles -->
    <link href="/css/app.css" rel="stylesheet">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    

<!-- Animate.css -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/animate.css')); ?>">
    <!-- Icomoon Icon Fonts-->
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/icomoon.css')); ?>">
    <!-- Bootstrap  -->

    <!-- Superfish -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/superfish.css')); ?>">
    <!-- Flexslider  -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/flexslider.css')); ?>">
    <!-- Magnific Popup -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/magnific-popup.css')); ?>">
    <!-- Date Picker -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/bootstrap-datepicker.min.css')); ?>">
    <!-- CS Select -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/cs-select.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/cs-skin-border.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(URL::asset('css/style.css')); ?>">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <link href="https://kit-free.fontawesome.com/releases/latest/css/free.min.css" media="all" rel="stylesheet">
    <script src="https://kit.fontawesome.com/f9262e0935.js" crossorigin="anonymous"></script>

    

<!-- Custom styles for this template -->
    

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
          integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <!-- Optional theme -->
    

    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.22/datatables.min.css"/>

    <style>


    </style>
</head>

<body class="bg-css">
<div>
    <nav class="navbar navbar-expand-lg navbar-inverse navbar-static-top navbar-dark bg-blue" >
        <a class="navbar-brand " href="/"><img src="<?php echo e(asset('logo/logowithout.png')); ?>" style="width:100%; max-width: 220px"></a>
        

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarsExample05" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse " id="navbarSupportedContent">
            <ul class="nav navbar-nav mr-auto">

                
                
                
                <?php if(!\Illuminate\Support\Facades\Auth::guest()): ?>
                    
                    <?php if(\Illuminate\Support\Facades\Auth::user()->role == 0): ?>
                        
                        <li class="nav-item">
                            <a class="special-link" href="/acceptedProperties">All Properties</a>
                        </li>
                        <li class="nav-item">
                            <a class="special-link" href="/allCommercials">All Commercials</a>
                        </li>
                        <li class="nav-item">
                            <a href="/users" class="special-link">All Users</a>
                        </li>
                        <li class="nav-item">
                            <a href="/agents" class="special-link">Agents</a>
                        </li>
                        <li class="nav-item">
                            <a href="/adminPayments" class="special-link">Payments</a>
                        </li>
                        <li class="nav-item">
                            <a href="/histories" class="special-link">Histories</a>
                        </li>
                    <?php else: ?>
                        
                        <li class="nav-item">
                            <a class="special-link" href="/properties/buy">Buy</a>
                        </li>

                        <li class="nav-item">
                            <a class="special-link" href="/properties/create">Sell</a>
                        </li>

                        <li class="nav-item">
                            <a class="special-link" href="/properties/rent">Rent / Share</a>
                        </li>


                        <li class="nav-item">
                            <a class="special-link" href="/properties/myProperties">My Properties</a>
                        </li>


                <li class="nav-item">
                    <a href="/findAgents" class="special-link">Find agent</a>
                </li>

                <li class="nav-item">
                    <a href="/tips" class="special-link">Tips</a>
                </li>
                <li class="nav-item">
                    <a href="/evaluate" class="special-link">Evaluate</a>
                </li>
                <li class="nav-item">
                    <a href="/insurance" class="special-link">Insurance</a>
                </li>

            </ul>
            <ul class="nav navbar-nav mr-auto">

                <li class="nav-item">
                    <a href="/commercial" class="special-link">Commercial</a>
                </li>


                <?php endif; ?>
                <?php endif; ?>
                <?php if(\Illuminate\Support\Facades\Auth::guest()): ?>
                    
                    <li class="nav-item">
                        <a class="special-link" href="/properties/buy">Buy</a>
                    </li>

                    <li class="nav-item">
                        <a class="special-link" href="<?php echo e(route('login')); ?>">Sell</a>
                    </li>

                    <li class="nav-item">
                        <a class="special-link" href="/properties/rent">Rent / Share</a>
                    </li>


                <li class="nav-item">
                    <a href="/findAgents" class="special-link">Find agent</a>
                </li>

                <li class="nav-item">
                    <a href="/tips" class="special-link">Tips</a>
                </li>
                <li class="nav-item">
                    <a href="/evaluate" class="special-link">Evaluate</a>
                </li>
                <li class="nav-item">
                    <a href="/insurance" class="special-link">Insurance</a>
                </li>

            </ul>
            <ul class="nav navbar-nav mr-auto">

                <li class="nav-item">
                    <a href="/commercial" class="special-link">Commercial</a>
                </li>

                <?php endif; ?>
            </ul>

            
            <ul class="navbar-nav ml-auto">
                <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item">
                        <a class="special-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                    </li>
                    <?php if(Route::has('register')): ?>
                        
                        <a class="special-link" href="<?php echo e(route('register')); ?>">Register</a>
                        


                    <?php endif; ?>
                <?php else: ?>

                    <li class="nav-item">
                        <a class="special-link mr-3" href="/users/<?php echo e(Auth::id()); ?>">

                            <img style="width: 40px; height: 40px; border-radius: 50%;"
                                 src="<?php echo e(url('/storage/user_profile_images/' . Auth::user()->profileImg )); ?>"
                            >
                            
                            
                            
                        </a>
                    </li>
                    <!li class="  m-1"><!/li>
                    <li>
                        <a class="btn btn-light  m-1" style="padding: 4px; color: #e4002b"
                           role="button" onclick="event.preventDefault();
                           document.getElementById('logout-form').submit();">Logout</a>

                        <div class="dropdown-menu dropdown-menu-right bg-dark" aria-labelledby="navbarDropdown">
                            
                            
                            
                            
                            

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>
</div>

<main class="m-0 p-0">
    <?php echo $__env->yieldContent('content'); ?>
</main>


<footer>

    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</footer>


</body>
</html>
<?php /**PATH C:\Users\reda\PhpstormProjects\Online-Store-Template\onlineStoreTemplate\resources\views/layouts/app.blade.php ENDPATH**/ ?>