<?php $__env->startSection('content'); ?>

    <div class="hero" style=" background-image: url(<?php echo e(asset('/images1/eval.jpg')); ?>);
    " >

        <div class="inner">
            <h1>Evaluate</h1>
        </div>
    </div>

    <Br><BR><BR>
                <div class="container p-5  bg-white">
                    <div class="card-header  ">

                        <h5 class="card-title text-center">Evaluation Form</h5>
                    </div>
                    <form method="GET" action="/submitEvaluation" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

            <div class="form-label-group">

                <label for="name"><?php echo e(__('Name')); ?>*</label>


                <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


            </div>


            <div class="form-label-group">
                <label for="email"><?php echo e(__('E-Mail Address')); ?>*</label>
                <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">

                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

                        <div class="form-label-group">
                            <label for="phoneNumber">Phone Number*</label>
                            <select id="phoneNumberCode" name="phoneNumberCode" class="form-control"
                                    style="display: none;">
                                <?php $__currentLoopData = \App\Models\CountryCode::orderBy('phonecode')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $countryCode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($countryCode->iso); ?>"
                                            <?php if($countryCode->phonecode == 61): ?> selected <?php endif; ?>>
                                        +<?php echo e($countryCode->phonecode); ?> - <?php echo e($countryCode->iso); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                            <input id="phoneNumber" type="number"
                                   class="form-control <?php $__errorArgs = ['phoneNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="phoneNumber"
                                   value="<?php echo e(old('phoneNumber')); ?>" required autocomplete="phoneNumber" autofocus>
                            <?php $__errorArgs = ['phoneNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <div class="form-label-group">

                <label for="location">Location</label>


                <input id="location" type="text" class="form-control <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       name="location" value="<?php echo e(old('location')); ?>" required autocomplete="location" autofocus>
                <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


            </div>
            <div class="form-label-group">

                <label for="description">Description</label>


                <textarea id="description" oninput="fun()" type="text" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                          name="description" value="<?php echo e(old('description')); ?>" required autocomplete="description" autofocus></textarea>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                


            </div>




            <div class="form-label-group">
                <label for="num_bed">Number of bedrooms</label>

                <input id="num_bed" type="number"
                       class="form-control <?php $__errorArgs = ['num_bed'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="num_bed"
                       value="<?php echo e(old('num_bed')); ?>" required autocomplete="num_bed" autofocus>
                <?php $__errorArgs = ['num_bed'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>


                        <div class="custom-control custom-checkbox mb-3">
                            <input type="checkbox" class="custom-control-input" name="owner"
                                   id="owner" onclick="validate()">
                            <label class="custom-control-label"
                                   for="owner">&nbsp;&nbsp;&nbsp;&nbsp; I am the owner of this user </label>
                        </div>

                        <div class="custom-control custom-checkbox mb-3">
                            <input type="checkbox" class="custom-control-input" name="check2"
                                   id="check2" onclick="validate()">
                            <label class="custom-control-label"
                                   for="check2">&nbsp;&nbsp;&nbsp;&nbsp; Note that the price will be given based on
                                research, area, and landsize </label>
                        </div>


                        <div class="form-group row mb-0">
                <div class="col-md-6 ">
                    <button type="submit" class=" btn-primary1" id="myBtn" disabled>
                        &nbsp;&nbsp;Send&nbsp;&nbsp;
                    </button>
                </div>
            </div>
        </form>

    </div>
                <script type=text/javascript>
                    function validate(){
                        if (owner.checked == 1 && check2.checked == 1 ){
                            document.getElementById("myBtn").disabled = false;
                        }
                        else{
                            document.getElementById("myBtn").disabled = true;
                        }
                    }
                </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\reda\PhpstormProjects\Online-Store-Template\onlineStoreTemplate\resources\views/evaluate.blade.php ENDPATH**/ ?>