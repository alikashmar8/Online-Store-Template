<?php $__env->startSection('content'); ?>

    <div class="hero" style=" background-image: url(<?php echo e(asset('/images1/log.jpg')); ?>);
    " >

        <div class="inner">
            <h1></h1>
        </div>
    </div>
    <BR><br>

    <div class="info1">

        <div class="top">
            <div id="private" class="decor" onclick="select_private()"><a>Private</a></div>
            <div id="agent" class="decor" onclick="select_agent()"><a>Agent</a></div>
        </div>

        <div class="details" id="d3">
            <div id="private-det">
                <div class="card-header "><h5 class="card-title text-center">Private <?php echo e(__('Register')); ?></h5></div>
                <form method="POST" action="<?php echo e(route('register')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <input id="role" type="hidden" name="role" value=2>


                    <div class="form-label-group">

                        <label for="name"><?php echo e(__('Name')); ?>*</label>


                        <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                    </div>

                    <div class="form-label-group" style="display: none;">

                        <label for="bio">Bio</label>
                        <textarea id="bio" type="text" class="form-control <?php $__errorArgs = ['bio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                  name="bio" value="<?php echo e(old('bio')); ?>" autocomplete="bio" autofocus  ></textarea>
                        <?php $__errorArgs = ['bio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-label-group">
                        <label for="email"><?php echo e(__('E-Mail Address')); ?>*</label>
                        <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">

                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>


                    <div class="form-label-group">
                        <label for="phoneNumber">Phone Number*</label>
                        <select id="phoneNumberCode" name="phoneNumberCode" style="cursor:no-drop; display: none"
                                class="form-control mx-3 mb-2">

                            <?php $__currentLoopData = \App\Models\CountryCode::orderBy('phonecode')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $countryCode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($countryCode->iso); ?>" style="display:none;"
                                        <?php if($countryCode->iso == 'AU'): ?> selected <?php else: ?> disabled <?php endif; ?>>
                                    +<?php echo e($countryCode->phonecode); ?> - <?php echo e($countryCode->iso); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                        <input id="phoneNumber" type="number"
                               class="form-control <?php $__errorArgs = ['phoneNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="phoneNumber"
                               value="<?php echo e(old('phoneNumber')); ?>" required autocomplete="phoneNumber" autofocus>
                        <?php $__errorArgs = ['phoneNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>


                    <div class="form-label-group" style="display: none;">
                        <label for="profileImg">Profile Image</label>
                        <input id="profileImg" type="file" class="<?php $__errorArgs = ['profileImg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> "
                               name="profileImg" value="<?php echo e(old('profileImg')); ?>" autocomplete="profileImg" autofocus>
                    </div>


                    <div class="form-label-group">
                        <label for="password"><?php echo e(__('Password')); ?>*</label>
                        <input id="password" type="password"
                               class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required
                               autocomplete="new-password">

                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>



                    <div class="form-label-group">
                        <label for="password-confirm"><?php echo e(__('Confirm Password')); ?>*</label>
                        <input id="password-confirm" type="password" class="form-control" name="password_confirmation"
                               required autocomplete="new-password">
                    </div>
                    <br>
                    <div class="form-group  mb-0">
                        <div class="col-md-6  ">
                            <button type="submit" class=" btn-primary1">
                                <?php echo e(__('Register')); ?>

                            </button>
                        </div>
                        <BR/>
                    </div>

                </form>

            </div>


            <div id="agent-det">
                <div class="card-header"><h5 class="card-title text-center">Agent <?php echo e(__('Register')); ?></h5></div>
                <form method="POST" action="<?php echo e(route('register')); ?>" enctype="multipart/form-data" id="agentForm">
                    <?php echo csrf_field(); ?>

                    <input id="role" type="hidden" name="role" value=1>

                    <div class="form-label-group">
                        <label for="name"><?php echo e(__('Name')); ?>*</label>
                        <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>


                    <div class="form-label-group">
                        <label for="licenseNumber">License Number*</label>
                        <input id="licenseNumber" type="number"
                               class="form-control <?php $__errorArgs = ['licenseNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               name="licenseNumber" value="<?php echo e(old('licenseNumber')); ?>" required
                               autocomplete="licenseNumber" autofocus>
                        <?php $__errorArgs = ['licenseNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                    </div>

                    <div class="form-label-group">

                        <label for="comp_name">Company Name*</label>
                        <input id="comp_name" type="text" class="form-control <?php $__errorArgs = ['comp_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               name="comp_name" value="<?php echo e(old('comp_name')); ?>" required autocomplete="comp_name"
                               autofocus>
                        <?php $__errorArgs = ['comp_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>



                    <div class="form-label-group">
                        <label for="email"><?php echo e(__('E-Mail Address')); ?>*</label>
                        <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">

                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>


                    <div class="form-label-group">
                        <label for="phoneNumber">Phone Number*</label>
                        <select id="phoneNumberCode" name="phoneNumberCode" style="cursor:no-drop; display: none"
                                class="form-control mx-3 mb-2" readonly="readonly">
                            <?php $__currentLoopData = \App\Models\CountryCode::orderBy('phonecode')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $countryCode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($countryCode->iso); ?>" style="display:none;"
                                        <?php if($countryCode->iso == 'AU'): ?> selected <?php else: ?> disabled <?php endif; ?>>
                                    +<?php echo e($countryCode->phonecode); ?> - <?php echo e($countryCode->iso); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                        <input id="phoneNumber" type="number"
                               class="form-control <?php $__errorArgs = ['phoneNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="phoneNumber"
                               value="<?php echo e(old('phoneNumber')); ?>" required autocomplete="phoneNumber" autofocus>
                        <?php $__errorArgs = ['phoneNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-label-group" style="display: none;">
                        <label for="profileImg">Profile Image</label>
                        <input id="profileImg" type="file" class="<?php $__errorArgs = ['profileImg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> "
                               name="profileImg" value="<?php echo e(old('profileImg')); ?>" autocomplete="profileImg" autofocus>

                    </div>

                    <div class="form-label-group">
                        <label for="password"><?php echo e(__('Password')); ?>*</label>

                        <input id="password" type="password"
                               class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required
                               autocomplete="new-password">

                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>



                    <div class="form-label-group">
                        <label for="password-confirm"><?php echo e(__('Confirm Password')); ?>*</label>
                        <input id="password-confirm" type="password" class="form-control" name="password_confirmation"
                               required autocomplete="new-password">
                    </div>


                    <div class="form-group  mb-0">
                        <div class="col-md-6 ">
                            <button type="submit" class=" btn-primary1">
                                <?php echo e(__('Register')); ?>

                            </button>
                        </div>
                    </div>
                </form>


            </div>


        </div>
    </div>

    <script>

        const loc = document.querySelector('#private-det');
        const con = document.querySelector('#agent-det');


        function select_private() {
            document.getElementById("private").style.background = "#e4002b";
            document.getElementById("private").style.color = "#ffffff";
            document.getElementById("agent").style.background = "#ffffff";
            document.getElementById("agent").style.color = "#e4002b";
            document.getElementById("d3").style.height = "650px";

            const t = new TimelineMax();
            t.fromTo(loc, 1.5, {height: "0%;"}, {height: "100%"})
                .fromTo(con, 1.5, {height: "100%;"}, {height: "0%"}, "-=1");

            document.getElementById("private-det").style.display = "block";
            document.getElementById("agent-det").style.display = "none";


        }

        function select_agent() {
            document.getElementById("private").style.background = "#ffffff";
            document.getElementById("private").style.color = "#e4002b";
            document.getElementById("agent").style.background = "#e4002b";
            document.getElementById("agent").style.color = "#ffffff";
            document.getElementById("d3").style.height = "800px";

            const t = new TimelineMax();
            t.fromTo(loc, 1, {height: "100%;"}, {height: "0%"})
                .fromTo(con, 1, {height: "0%;"}, {height: "100%"}, "-=1");


            document.getElementById("private-det").style.display = "none";
            document.getElementById("agent-det").style.display = "block";


        }


    </script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/2.1.3/TweenMax.min.js"
                integrity="sha512-DkPsH9LzNzZaZjCszwKrooKwgjArJDiEjA5tTgr3YX4E6TYv93ICS8T41yFHJnnSmGpnf0Mvb5NhScYbwvhn2w=="
                crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/2.1.3/TimelineMax.min.js"
                integrity="sha512-0xrMWUXzEAc+VY7k48pWd5YT6ig03p4KARKxs4Bqxb9atrcn2fV41fWs+YXTKb8lD2sbPAmZMjKENiyzM/Gagw=="
                crossorigin="anonymous"></script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\reda\PhpstormProjects\Online-Store-Template\onlineStoreTemplate\resources\views/auth/register.blade.php ENDPATH**/ ?>