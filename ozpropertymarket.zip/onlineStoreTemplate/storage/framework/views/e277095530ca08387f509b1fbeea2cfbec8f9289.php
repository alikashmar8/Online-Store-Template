


<div class="container p-0">

    <?php if(count($results) > 0): ?>
        <H3>Results for '<?php echo e($searched); ?>':</H3><br/>
        <h4><?php echo e(count($results ?? '')); ?> agent(s) available !</h4>
        <?php if($type == 'agents'): ?>
            <center>
            <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                
                
                

                
                
                
                
                
                
                
                
                
                
                
                <div class="p-4 text-center animate-box" style="display: inline-block" data-animate-effect="fadeIn">
                    <div class="fh5co-staff profile" style="background-color: transparent !important; margin: 0px !important;">
                        <img class="img-thumbnail"
                             src="<?php echo e(url('/storage/user_profile_images/' . $agent->profileImg)); ?>" alt="Profile Picture">
                        <h3><?php echo e($agent->name); ?></h3>
                        <p><a style="font-weight: bold;color: #000000">Company:</a> <?php echo e($agent->company->name); ?></p>
                        <p><a style="font-weight: bold;color: #000000">Phone number:</a> +<?php echo e($agent->phoneNumberCode); ?> - <?php echo e($agent->phoneNumber); ?></p>
                        <p><a style="font-weight: bold;color: #000000"> Email:</a> <?php echo e($agent->email); ?></p>
                    </div>
                </div>
                
                

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </center>
        <?php else: ?>
            <?php echo e($results ?? ''); ?>

        <?php endif; ?>
    <?php else: ?>
        <h3 class="post">No results found for : '<?php echo e($searched); ?>' !</h3>
    <?php endif; ?>
</div>

<?php /**PATH C:\Users\reda\PhpstormProjects\Online-Store-Template\onlineStoreTemplate\resources\views/searchResults.blade.php ENDPATH**/ ?>