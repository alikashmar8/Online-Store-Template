<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="p-2"></div>
        <div class="post p-4 my-5">
            <h1>Edit Property:</h1>
            <div class="alert alert-warning">Editing your user will need admin confirmation to get listed again!
            </div>

            <?php echo e(Form::open(['action' => ['App\Http\Controllers\PropertiesController@update',$user->id],'method'=>'PUT','files' => true])); ?>

            <div class=" creat_app">
                <div class=" ">
                    <div class=" form-group form-label-group special ">
                        <?php echo e(Form::label('price','Price:')); ?>

                        <?php echo e(Form::number('price',$user->price,['min' => '0','class' => 'form-control','placeholder'=>'Price'])); ?>

                        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class=" form-group form-label-group special ">
                        <?php if($user->showPrice == 0): ?>
                            <?php echo e(Form::checkbox('showPrice',0, false)); ?>

                        <?php else: ?>
                            <?php echo e(Form::checkbox('showPrice',1, true)); ?>

                        <?php endif; ?>
                        <?php echo e(Form::label('showPrice','Show Price')); ?>

                    </div>
                    <div class="form-group form-label-group">
                        <?php echo e(Form::label('bedroomsNumber','Number Of Bedrooms:')); ?>

                        <?php echo e(Form::select('bedroomsNumber',array(0=> 0,1,2,3,4,5=>'5+'),$user->bedroomsNumber,['class' => 'form-control'])); ?>

                    </div>

                    <div class="form-group form-label-group">
                        <?php echo e(Form::label('bathroomsNumber','Number Of Bathrooms:')); ?>

                        <?php echo e(Form::select('bathroomsNumber',array(0=> 0,1,2,3,4=>'4+'),$user->bathroomsNumber,['class' => 'form-control'])); ?>

                    </div>
                    <div class="form-group form-label-group">
                        <?php echo e(Form::label('parkingNumber','Number Of Parking:')); ?>

                        <?php echo e(Form::select('parkingNumber',array(0=> 0,1,2,3,4=>'4+'),$user->parkingNumber,['class' => 'form-control'])); ?>

                    </div>
                    <div class="form-group form-label-group">
                        <?php echo e(Form::label('category','Listing Type:')); ?>

                        <select name="category">
                            <?php $__currentLoopData = \App\Models\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($type->id); ?>"
                                        <?php if($type->id == $user->categoryId): ?> selected <?php endif; ?> ><?php echo e($type->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group form-label-group">
                        <?php echo e(Form::label('type','Property Type:')); ?>

                        <select name="type">
                            <?php $__currentLoopData = \App\Models\PropertyType::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($type->id); ?>"
                                        <?php if($type->id == $user->typeId): ?> selected <?php endif; ?>><?php echo e($type->title); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group form-label-group special">
                        <?php echo e(Form::label('description','Description:')); ?>

                        <?php echo e(Form::textarea('description',$user->description,['class' => 'form-control','placeholder'=>'Description'])); ?>

                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group form-label-group special">
                        <input type="checkbox" name="changeImages" onclick="imgs2()"> Change images
                    </div>

                    <div class="form-group form-label-group special" id="imgs" style="display: none">
                        <?php echo e(Form::label('images','Images:')); ?>

                        <div class="form-group form-label-group">
                            <input type="file" name="images[]" id="file" accept=".png, .jpg, .mp4" multiple>
                            <script>
                                var uploadField = document.getElementById("file");

                                uploadField.onchange = function () {
                                    var i = 0;
                                    var space = 0;
                                    for (i = 0; i < this.files.length; i++) {
                                        space += this.files[i].size

                                    }
                                    if (space > 150000000) {
                                        alert("Files are too big!");
                                        this.value = "";
                                    }
                                    ;
                                };
                            </script>
                            <?php $__errorArgs = ['images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-label-group">
                <?php echo e(Form::submit('Edit',['class'=>'btn btn-primary1'])); ?>

            </div>
            <?php echo e(Form::close()); ?>

        </div>
        <div class="p-3"></div>
    </div>

    <script>
        var imgs1= 0;
        function imgs2(){
            if (imgs1 == 0){
                document.getElementById("imgs").style.display = "block";
                imgs1=1;
            }
            else {
                document.getElementById("imgs").style.display = "none";
                imgs1=0;
            }
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\reda\PhpstormProjects\Online-Store-Template\onlineStoreTemplate\resources\views/properties/edit.blade.php ENDPATH**/ ?>