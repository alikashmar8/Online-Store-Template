<?php $__env->startSection('content'); ?>

    <div class="main-content">
        <div class="main2">
            <div class="container  ">
                <?php if(session()->has('message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                <?php endif; ?>
                <?php if(!\Illuminate\Support\Facades\Auth::guest()): ?>
                    <?php if(\Illuminate\Support\Facades\Auth::user()->id == $com->userId): ?>
                        
                        <div class=" ">

                            <?php if($com->accepted == 0): ?>
                                
                                <?php if($com->extra1 != null): ?>
                                    <div class="alert alert-danger">
                                        Your user is hidden currently, press show to make it visible!
                                        <a class="btn btn-success " href="/userShowCommercial?id=<?php echo e($com->id); ?>">Show</a>
                                    </div>

                                <?php else: ?>
                                    <div class="alert alert-danger">
                                        Your user is not accepted yet! Kindly wait admin confirmation.
                                    </div>

                                <?php endif; ?>
                            <?php else: ?>
                                <div class="alert alert-info"> Your user listed successfully.
                                    Press 'hide' button to hide it temporarily.
                                    <a class="btn btn-danger " href="/userHideCommercial?id=<?php echo e($com->id); ?>">Hide</a>
                                </div>

                            <?php endif; ?>


                        </div>
                    <?php endif; ?>
                <?php endif; ?>
                <div class="post ">

                    <div id="carouselEx" class="carousel slide carousel-fade " data-ride="carousel">
                        <div class="carousel-inner">
                            <?php if(count($com->images)>0): ?>
                                <?php $__currentLoopData = $com->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="carousel-item <?php if($loop->first): ?> active <?php endif; ?>"  style="position: relative; z-index :1;top :0;left :0;width :100%;height :50vw;overflow :hidden;display: flex;" >
                                        <?php if(pathinfo($image->url, PATHINFO_EXTENSION) ==='mp4'): ?>
                                            <video class="d-block w-100"
                                                   style="  height: 100%; width: 800px;object-fit: cover;"
                                                   autoplay controls muted>
                                                <source
                                                    src="<?php echo e(url('/storage/commercials_images/' . $image->url)); ?>"
                                                    type="video/mp4" >

                                            </video>
                                        <?php else: ?>
                                            <img class="d-block w-100"  style="height: 50vw; width: 800px;object-fit: contain;"
                                                 src="<?php echo e(url('/storage/commercials_images/' . $image->url)); ?>"
                                                 alt="No Image">
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <img class="d-block w-100"
                                     src="<?php echo e(url('/storage/commercials_images/unavailable.jpg')); ?>"
                                     alt="No Image">
                            <?php endif; ?>

                        </div>
                        <a class="carousel-control-prev" href="#carouselEx" role="button"
                           data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true">
                        <i class="fa fa-chevron-left" style="color: #df0505" aria-hidden="true"></i>
                    </span>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="carousel-control-next" href="#carouselEx" role="button"
                           data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true">
                        <i class="fa fa-chevron-right" style="color: #df0505" aria-hidden="true"></i>
                    </span>
                            <span class="sr-only">Next</span>
                        </a>
                    </div>
                    <div class="dkn">

                        <div class="">
                            <h3>Details:</h3>

                            <a class="btn-primary1 m-3 p-2 float-right" style="color: white" href="/comBrochure/<?php echo e($com->id); ?>"> <i class="fas fa-paste"></i> Brochure </a>
                            <hr>

                            <div class="post-details ">

                                <p class="price"><?php echo e($com->location); ?> </p>


                                <p style="font-size: 22px">
                                    <i class="fas fa-ruler-combined"></i> <?php echo e($com->floor); ?>m<sup>2</sup>
                                    | <?php echo e(\App\Models\commTypes::findOrFail($com->type)->title); ?>

                                </p>

                                <?php if($com->showPrice == 1): ?>  <p class="price">
                                    $ <?php echo e($com->price); ?> </p>

                                <?php else: ?>
                                    <p class="price">Contact the agent for the price</p>
                                <?php endif; ?>


                                <div class="row"></div>
                                <p style="white-space: pre-line">
                                    <a style="font-size:25px; font-weight: 600;  ">Description:</a>
                                    <?php echo e($com->description); ?>

                                </p>
                                <p><a style="font-size:25px; font-weight: 600;  ">Placed On:</a>
                                    <?php echo e($com->created_at->toDateString()); ?></p>
                            </div>
                        </div>

                        <br/><br/>
                        <div class="">
                            
                            <p id="lat" style="display: none"><?php echo e($com->lan); ?></p>
                            <p id="lng" style="display: none"><?php echo e($com->lang); ?></p>

                            <h3>Location</h3>
                            <br/>

                            <div id="map" style="height: 400px;  width: 100%;"></div>

                            <script>
                                var lat1 = document.getElementById('lat').innerHTML
                                var lng1 = document.getElementById('lng').innerHTML

                                function initMap() {

                                    var location = {lat: parseFloat(lat1), lng: parseFloat(lng1)};

                                    var map = new google.maps.Map(
                                        document.getElementById('map'), {zoom: 15, center: location});

                                    var marker = new google.maps.Marker({
                                        position: location,
                                        map: map   /* , icon:'pinkball.png'*/
                                    });
                                }
                            </script>

                            <script async defer
                                    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB1CbPQ2HCLV38r9m68B8VCv51JBVke5TM&callback=initMap"></script>


                        </div>

                        <br/><br/>


                        <?php if(\Illuminate\Support\Facades\Auth::guest()): ?>
                            <div class="">
                                <h3>Login to get the contact information</h3>
                            </div>
                        <?php else: ?>


                            <div class="">
                                <hr>

                                <h4>Admin Notes:</h4>
                                <p style="white-space: pre-line; border: none; border-left: 3px solid #e4002b;   padding: 20px; color: #0a0807"> <?php echo e($com->extra1); ?>

                                </p>
                                <BR/>

                                <hr>
                                <?php if($com->userId != \Illuminate\Support\Facades\Auth::id()): ?>

                                    <form action="/contactForProperty" method="get">
                                        <?php echo csrf_field(); ?>
                                        <h4>Contact the owner about this user:</h4><br/>

                                        <input type="hidden" value="<?php echo e($com->id); ?>" name="id">
                                        <input type="hidden" value="<?php echo e($com->agent->email); ?>"
                                               name="email1">
                                        <div class="form-label-group">
                                            <label class="form-label-group" for="message">Message:</label>
                                            <textarea name="message" class="form-control"
                                                      style="height: 300px ; margin-top: 10px;"
                                                      required>
Hi, I am interested to view your user! What is the best time to inspect?
Thanks

Hi, How much is the last price for your user?
Thanks
                                        </textarea>

                                        </div>
                                        <input type="submit" value="Send" class="btn-primary1">

                                    </form>
                                    <?php if($com->userId != \Illuminate\Support\Facades\Auth::id()): ?>
                                        <hr>
                                        <form action="/reportProperty" method="get">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" value="/commercial/<?php echo e($com->id); ?>" name="id">

                                            <div class="form-label-group">
                                                <h6>Report this listing:</h6>
                                                <label class="form-label-group" for="message">
                                                    <small>
                                                        If there is inappropriate or incorrect details please report this listing.
                                                    </small>
                                                </label>


                                            </div>
                                            <input type="submit" value="Send" class="btn-primary1" style="font-size: 12px;padding: 3px">

                                        </form>
                                    <?php endif; ?>

                                <?php else: ?>
                                    <h4>Current Package</h4>
                                    <?php if($com->extra3 > 0): ?>
                                        <p>
                                            <?php echo e(\App\Models\Packages::findOrFail($com->extra3)->title); ?>

                                        </p>
                                    <?php else: ?>
                                        <p> Please use a package for this property to be listed </p>
                                    <?php endif; ?>
                                    <div class="  form-label-group">
                                        <div class="row">

                                            <form action="<?php echo e(route('upgradePackageCommercial')); ?>" method="post"  >
                                                <?php echo csrf_field(); ?>
                                                <br/>
                                                <label for="newPackageId">Upgrade your current package for this property:</label>
                                                <br/>
                                                <select name="newPackageId" id="newPackageId" style="font-size: 13px">
                                                    <?php $__currentLoopData = \App\Models\Packages::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if( $a->id  > 7  ): ?>
                                                                <option value="<?php echo e($a->id); ?>"><?php echo e($a->title); ?> </option>

                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>

                                                <input type="hidden" name="oldPackage" value="<?php echo e($com->extra3); ?>">
                                                <input type="hidden" name="propertyId" value="<?php echo e($com->id); ?>">
                                                <input type="submit" value="Upgrade" class="btn-primary1 float-right" style="color: #fff">
                                            </form>
                                        </div>
                                    </div>


                                    <?php if($com->extra3 == 6 ||$com->extra3 == 7 ||$com->extra3 == 11 || $com->extra3 == 12 ||$com->extra3 == 13 ): ?>
                                        <hr>
                                        <h4>PDF Application</h4>
                                        <div class="  form-label-group">
                                            <div class="row">

                                                <form action="<?php echo e(route('getPdf')); ?>" method="get"  >
                                                    <?php echo csrf_field(); ?>
                                                    <br/>
                                                    <label for="state">Select the state:</label>
                                                    <br/>
                                                    <select name="state" id="state" >
                                                        <option value="WA">WA </option>
                                                        <option value="SA">SA </option>
                                                        <option value="NSW">NSW </option>
                                                        <option value="NT">NT </option>
                                                        <option value="VIC">VIC </option>
                                                        <option value="QLD">QLD </option>
                                                        <option value="ACT">ACT </option>
                                                    </select>
                                                    <input type="submit" value="Download" class="btn-primary1 float-right" style="color: #fff">
                                                </form>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>

                        <br><br>


                    </div>


                </div>
            </div>
        </div>
        <div class="main3">

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\reda\PhpstormProjects\Online-Store-Template\onlineStoreTemplate\resources\views/commercial/showCommercial.blade.php ENDPATH**/ ?>