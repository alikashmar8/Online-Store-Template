
<body style="margin: 15px;background: #ffffff ; font-family: 'Roboto', sans-serif;">
    <div style="text-align: center; width: 100%; margin: auto; ">
        <img src="<?php echo e(asset('/images1/logo.png')); ?>" style="max-height: 150px" >
    </div>
    <bR/>
    <div style="width: 85%; background: #fff; color: #0a0807;text-align: left;   margin: auto; padding: 20px">
        <h1> New Property is Added </h1>




    <?php $__env->startComponent('mail::button', ['url' => URL::to('/acceptProperties')]); ?>
        Check It
    <?php if (isset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e)): ?>
<?php $component = $__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e; ?>
<?php unset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

    Thank you,<br>
        <hr>
        <h2>OZ Property Market</h2>

            <p ><small >© 2020 Real Estate, all Rights Reserved. Developed by <a href="https://webside.com.au/" target="_blank" style="color: #e4002b">WebSide</a> </small></p>

    </div>
</body>



<?php /**PATH C:\Users\reda\PhpstormProjects\Online-Store-Template\onlineStoreTemplate\resources\views/emails/newProperty.blade.php ENDPATH**/ ?>