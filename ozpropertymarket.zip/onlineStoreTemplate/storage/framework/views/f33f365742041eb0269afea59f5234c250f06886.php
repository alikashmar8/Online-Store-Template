

<?php $__env->startSection('content'); ?>
    <div class="hero" style="height: 120px;  background-image: linear-gradient(#df0505, #f5f5f5);

    ">
        <div class="inner">

        </div>
    </div>
    <h1 style=" text-align: center">Details</h1>
    <BR><BR>

    <div class="container bg-white " style="overflow-y: scroll;">
        <div >
            <?php if($type == 'property' || $type == 'commercial'): ?>
                <table class="table1" id="myDataTable">
                    <thead class="thead-dark">
                    <tr>
                        <th scope="col">Property ID</th>
                        <th scope="col">Description</th>
                        <?php if($type != 'commercial'): ?>
                        <th scope="col">Bathrooms Number</th>
                        <th scope="col">Parking Number</th>
                        <th scope="col">Bedrooms Number</th>
                        <?php endif; ?>
                        <?php if($type == 'commercial'): ?>
                            <th scope="col">Floors</th>
                        <?php endif; ?>
                        <th scope="col">Accepted</th>
                        <th scope="col">Creator Id</th>
                        <th scope="col">Category</th>
                        <th scope="col">Type</th>
                        <th scope="col">Location</th>
                        <th scope="col">Admin Contact Info</th>
                        <th scope="col">Longitude</th>
                        <th scope="col">Latitude</th>
                        <th scope="col">Operation Date</th>
                    </tr>
                    </thead>
                    <tbody class="">
                    <?php $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr <?php if($property->isCreated == 1): ?>style="background-color: #88df9c"
                            <?php endif; ?> <?php if($property->isDeleted == 1): ?>class="bg-danger"
                            <?php endif; ?> <?php if($property->isUpdated == 1): ?>style="background-color: #9a9ea1" <?php endif; ?>>

                            <td>
                                <?php if($type != 'commercial'): ?><?php echo e($property->propertyId); ?>

                                <?php elseif($type == 'commercial'): ?><?php echo e($property->commercialId); ?>

                                <?php endif; ?>
                            </td>

                            <td>
                                <p style="white-space: pre-line;color: #23272b">
                                    <?php echo e($property->post_description); ?>

                                </p>
                            </td>

                            <?php if($type != 'commercial'): ?>
                                <td><?php echo e($property->post_bathroomsNumber); ?></td>
                                <td><?php echo e($property->post_parkingNumber); ?></td>
                                <td><?php echo e($property->post_bedroomsNumber); ?></td>
                            <?php endif; ?>

                            <?php if($type == 'commercial'): ?>
                                <td><?php echo e($property->commercial_floor); ?></td>
                            <?php endif; ?>

                            <td>
                                <?php if($property->post_accepted == 0): ?>False
                                <?php else: ?> True
                                <?php endif; ?>
                            </td>

                            <td>
                                <a href="/users/<?php echo e($property->post_userId); ?>" style="color: #23272b">
                                    <?php echo e($property->post_userId); ?>

                                </a>
                            </td>
                            <td><?php echo e($property->post_category); ?></td>
                            <td><?php echo e($property->post_type); ?></td>
                            <td><?php echo e($property->post_locationDescription); ?></td>
                            <td><?php echo e($property->post_contactInfo); ?></td>
                            <td><?php echo e($property->post_longitude); ?></td>
                            <td><?php echo e($property->post_latitude); ?></td>
                            <td><?php echo e($property->created_at); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>
                <table class="table1" id="myDataTable">
                    <thead class="">
                    <tr>
                        <th scope="col">User ID</th>
                        <th scope="col">Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Role</th>
                        <th scope="col">PhoneNumber</th>
                        <th scope="col">Bio</th>
                        <th scope="col">Operation Date</th>
                    </tr>
                    </thead>
                    <tbody class="">
                    <?php $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr <?php if($user->isCreated == 1): ?> class="bg-success"
                            <?php endif; ?> <?php if($user->isDeleted == 1): ?>class="bg-danger"
                            <?php endif; ?> <?php if($user->isUpdated == 1): ?>class="bg-secondary" <?php endif; ?> >
                            <td><?php echo e($user->userId); ?></td>
                            <td><?php echo e($user->user_name); ?></td>
                            <td><?php echo e($user->user_email); ?></td>
                            <?php if($user->user_role == 0): ?>
                                <td>Admin</td><?php endif; ?>
                            <?php if($user->user_role == 1): ?>
                                <td>Agent</td><?php endif; ?> <?php if($user->user_role == 2): ?>
                                <td>Normal User</td><?php endif; ?>
                            <td>+<?php echo e($user->user_phoneNumberCode); ?> <?php echo e($user->user_phoneNumber); ?></td>
                            <td><p style="white-space: pre-line; color: #212529" ><?php echo e($user->user_bio); ?></p></td>
                            <td><?php echo e($user->created_at); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            <?php endif; ?>

        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
            integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
            crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
            integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN"
            crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"
            integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV"
            crossorigin="anonymous"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.22/datatables.min.js"></script>
    <script type="text/JavaScript"
            src="https://cdn.datatables.net/1.10.18/js/dataTables.bootstrap4.min.js"></script>
    <script>
        var table = $('#myDataTable').DataTable({
            "columnDefs": [
                {"orderable": false, "targets": 0},
            ]
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\reda\PhpstormProjects\Online-Store-Template\onlineStoreTemplate\resources\views/Histories/show.blade.php ENDPATH**/ ?>