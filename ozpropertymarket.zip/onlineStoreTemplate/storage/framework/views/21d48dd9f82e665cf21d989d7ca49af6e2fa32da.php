

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="p-2"></div>
        <div class="post p-4 m-5">
            <h1>Edit Commertcial Property:</h1>
            <div class="alert alert-warning">Editing your user will need admin confirmation to get listed again!
            </div>


            
            <div class=" creat_app">

                <form action="<?php echo e(route('updateCommercial')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="">
                        <div class="raw ">

                            <input type="hidden" name="id" value="<?php echo e($com->id); ?>">

                            <div class="  form-label-group">
                                <label for="price" >Price: </label>
                                <input type="number" id="price" name="price" min="0" class="" value="<?php echo e($com->price); ?>"  placeholder ="Price" required="">
                                <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div><BR/>

                            <div class="  form-label-group special">

                                <input type="checkbox" name="showPrice"  checked>
                                <label for="showPrice">Show Price</label>
                            </div><BR/>
                            <div class="  form-label-group">
                                <label for="category">Listing Type:</label>

                                <select name="category">
                                    <option value="1"   >Sell</option>
                                    <option value="2" >Lease</option>
                                    <option value="3"  >Invest</option>
                                </select>
                            </div><BR/>
                            <div class="  form-label-group">
                                <label for="type">Property Type:</label>

                                <select name="type">

                                    <?php $__currentLoopData = \App\Models\commTypes::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($type->id); ?>"   ><?php echo e($type->title); ?> </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div><BR/>



                            <div class="  form-label-group">
                                <label for="floor">Floor: </label>
                                <input type="number" name="floor" id="floor" value="<?php echo e($com->floor); ?>" class="" placeholder="Floor" required="">
                            </div><BR/>



                            <div class="  form-label-group">
                                <label for="description">Description</label>
                                <textarea name="description" id="description" class="" placeholder="Description" required="" ><?php echo e($com->description); ?></textarea>
                                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="alert-danger" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div><BR/>


                            <div class="form-group form-label-group special">
                                <input type="checkbox" name="changeImages" onclick="imgs2()"> Change images
                            </div>

                            <div class="form-group form-label-group special" id="imgs" style="display: none">
                                <label for="images" >Images</label>
                                <input type="file" name="images[]" id="file" accept=".png, .jpg, .mp4" multiple>
                                <i class='far fa-question-circle' data-toggle="tooltip" data-placement="top"
                                   title="Supported file types are (mp4/jpg/png)"></i>
                                <br>
                                <small class="ml-3">Total max size = 100M</small>


                                <script>
                                    var uploadField = document.getElementById("file");

                                    uploadField.onchange = function () {
                                        var i = 0;
                                        var space = 0;
                                        for (i = 0; i < this.files.length; i++) {
                                            space += this.files[i].size

                                        }
                                        if (space > 150000000) {
                                            alert("Files are too big!");
                                            this.value = "";
                                        }

                                    }
                                </script>
                                <?php $__errorArgs = ['images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="alert-danger" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div><BR/>


                        </div>
                    </div>




                    <input type="submit" name="submit" id="submit" class="btn-primary1">


                </form>



        </div>
        <div class="p-3"></div>
    </div>
    </div>

    <script>
        var imgs1= 0;
        function imgs2(){
            if (imgs1 == 0){
                document.getElementById("imgs").style.display = "block";
                imgs1=1;
            }
            else {
                document.getElementById("imgs").style.display = "none";
                imgs1=0;
            }
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\reda\PhpstormProjects\Online-Store-Template\onlineStoreTemplate\resources\views/commercial/editCommercial.blade.php ENDPATH**/ ?>