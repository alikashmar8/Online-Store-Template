<?php $__env->startSection('content'); ?>

    <div class="hero" style=" height: 500px; background-image: url(<?php echo e(asset('/images1/insurance.jpg')); ?>);
    " >

        <div class="inner">
            <H1>Insurance</H1>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\reda\PhpstormProjects\Online-Store-Template\onlineStoreTemplate\resources\views/insurance.blade.php ENDPATH**/ ?>