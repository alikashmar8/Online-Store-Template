<?php $__env->startSection('content'); ?>
<div class="container">

    <?php if(session()->has('message')): ?>
        <div class="alert alert-danger">
            <?php echo e(session()->get('message')); ?>

        </div>
    <?php endif; ?>
</div>

    <?php echo $__env->make('Packages.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\reda\PhpstormProjects\Online-Store-Template\onlineStoreTemplate\resources\views/Packages/packages.blade.php ENDPATH**/ ?>