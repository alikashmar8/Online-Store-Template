<body style="margin: 15px;background: #e4002b ; font-family: 'Roboto', sans-serif;">
<div style="text-align: center; width: 100%; margin: auto; ">
    <img src="https://webside.com.au/MK/hackathon/imagaga123/images1/logo.png" style="max-height: 150px">
</div>
<bR/>
<div style="width: 85%; background: #fff; color: #0a0807;text-align: left;   margin: auto; padding: 20px">
    <h1>Reset Password</h1>
    Forgotten your password?
    <br>

    You have been sent this email because we received a request to reset the password to your account.
    <br>
    To do this, please click the button below to enter a new password of your choice.

    <?php $__env->startComponent('mail::button', ['url' => URL::to('password/reset/' . $token . '?email=' . urlencode($email))]); ?>
        Click Here
    <?php if (isset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e)): ?>
<?php $component = $__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e; ?>
<?php unset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

    <br>
    If you have not sent a request to reset your password, please ignore this email.
    <br>
    Thank you,<br>
    <hr>
    <h2>OZ Property Market</h2>

    <p><small>© 2020 Real Estate, all Rights Reserved. Developed by <a href="https://webside.xyz/" target="_blank"
                                                                       style="color: #e4002b">WebSide</a> </small></p>

</div>
</body>




<?php /**PATH C:\Users\reda\PhpstormProjects\Online-Store-Template\onlineStoreTemplate\resources\views/emails/resetPassword.blade.php ENDPATH**/ ?>