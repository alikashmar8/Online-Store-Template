@extends('layouts.app')

@section('content')

    <div class="hero" style=" background-image: url({{asset('/images1/sell.jpg')}});
    " >

        <div class="inner">
            <h1>Oz Property Market Packages</h1>
        </div>
    </div>
@endsection
