@extends('layouts.app')

@section('content')

    <div class="hero" style=" height: 500px; background-image: url({{asset('/images1/insurance.jpg')}});
    " >

        <div class="inner">
            <H1>Insurance</H1>
        </div>
    </div>


@endsection
